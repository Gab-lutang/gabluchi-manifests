-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 8870.lua
--Gamename BioShock Infinite
addappid(8870, 1, "21a8e0a22d212495226c1b707f9ea10e69e778ee548cb0664d80bb9d37ad1e3d") --Mainappid BioShock Infinite
addappid(8871, 1, "15d71754689fb151612e0f9fd4f836da3d1ae06fefa921ea7e0d5244024c2139") --Main Windows/Linux Language Depot Schinese BioShock Infinite
setManifestid(8871, "7039415372102975608", 5096656)
addappid(8873, 1, "34259630cec28c6fe5f2234978d30681f84e83e1f02d1c98083d2c2df79bbbea") --Main Windows/Linux Depot BioShock Infinite
setManifestid(8873, "8906668488879681674", 3674096)
addappid(8874, 1, "2fdd7f8985053716cf8af83b059625bf5b05c29656291b8bb5cb0d3129ee42d3") --Main Windows/Linux Depot BioShock Infinite
setManifestid(8874, "5210440950602438279", 61712)
addappid(8875, 1, "d607e6a124cd9321017c7ed9a8568b05fe34ef3a2f22b51849ced527388368c8") --Main Windows/Linux Depot BioShock Infinite
setManifestid(8875, "2405586694981548561", 337797184)
addappid(8876, 1, "811fc2ec3fe3e3310f1749cd384681c4329341f3cddec04868b4324fec3b3ef2") --Main Windows/Linux Depot BioShock Infinite
setManifestid(8876, "6768402156929332351", 1508919712)
addappid(8877, 1, "d5ab7b35c58cdd630de5d515a1685798e8ed12c2ebaa44ed2abb5df554045fd6") --Main Windows/Linux Depot BioShock Infinite
setManifestid(8877, "4451629351774366864", 14004509648)
addappid(8878, 1, "0b51342da3c2d54a398c08a62b3f31c391ad027a485c78a859d8224258a77709") --Main Windows Depot BioShock Infinite
setManifestid(8878, "825143785808203324", 120248480)
addappid(214939, 1, "0dd2d51514170da12149248292e9beffc75dd150fb40d459a35bb07ca7561b7a") --Main Windows/Linux Language Depot Tchinese BioShock Infinite
setManifestid(214939, "7541205748729306494", 6866752)
addappid(214940, 1, "217edd544129caf03c7606a9ac1e9b10a051f1aa7708b3fdeb2338bb8610fcd6") --Main Linux Depot BioShock Infinite
setManifestid(214940, "7890907118462712083", 21711008)
addappid(224081, 1, "f9b8e24a258629aa6c139e2fef4a9a7eea88b5cd8b137519a46f945e89981c57") --Main Windows/Linux Language Depot German BioShock Infinite
setManifestid(224081, "2265476386352157140", 352256528)
addappid(224082, 1, "f0ec2976f6311f6537b32c319023af353b15561af169a26f94f280f21a149d1f") --Main Windows/Linux Language Depot Spanish BioShock Infinite
setManifestid(224082, "6616671147263879263", 351819680)
addappid(224083, 1, "f075cac0a531d78e81f9a26a337b6078becd3d2abebd7b41e79d9d1ea6b26c6b") --Main Windows/Linux Language Depot French BioShock Infinite
setManifestid(224083, "129123686946516370", 347497968)
addappid(224084, 1, "5212f37bff4d7365d91fcada8dcb41661cf848ccfa03e6fcb3a59567f93ab72d") --Main Windows/Linux Language Depot Italian BioShock Infinite
setManifestid(224084, "5152904412597912093", 350765680)
addappid(224085, 1, "5a3d719e4588b0d88c3d0d2eef0c342619f86ecd98cf1ff5369eb74d6fea4683") --Main Windows/Linux Language Depot Japanese BioShock Infinite
setManifestid(224085, "9073117651496736612", 344415552)
addappid(224086, 1, "e595bd6c1ce82c41ea4f1b0e697459120eba4f4d2f2e4e215a76dca0ee14f6aa") --Main Windows/Linux Language Depot Polish BioShock Infinite
setManifestid(224086, "2017736402435578056", 401712)
addappid(224087, 1, "4cc54399825cf68ff8c82659320d2d5b314aa58bb378a30c590021f03394e9bf") --Main Windows/Linux Language Depot Brazilian BioShock Infinite
setManifestid(224087, "1975820974150653093", 402256)
addappid(224088, 1, "db5540f1e78d6c89e9144975601b6b7aa0c1b80d42319a52b688371950bf4214") --Main Windows/Linux Language Depot Russian BioShock Infinite
setManifestid(224088, "1516624611492498647", 397648)
addappid(224089, 1, "e0da94a12e19749d7960a583a8c15a9b496ca9649bb5fe9c4360ae3749a7db33") --Main Windows/Linux Language Depot Koreana BioShock Infinite
setManifestid(224089, "8244553622212338428", 357680)
addappid(224091, 1, "b94a9cbd1e44ebe744d960186af1678123ba134a8cc08fd8e5020ca153416011") --Main Windows Depot BioShock Infinite
setManifestid(224091, "91002656285939010", 109916112)
addappid(243401, 1, "0eb25a84b39433d7ccf1c0032f3ffd5adfd37111c879c6f2f4a2a2002449c17a") --Main Macos Depot BioShock Infinite
setManifestid(243401, "1512127125101102497", 1642821168)
addappid(243402, 1, "351447d46049eed6ad3e6f29a92d753d21c2d8dc42e1b1d1069ec7399746226e") --Main Macos Depot BioShock Infinite
setManifestid(243402, "6496097600182155812", 1997273681160)
addappid(243403, 1, "b449acfcc5a4321aec79a05b2854ec4c683eed7e89202d50202c503e249c37d6") --Main Macos Depot BioShock Infinite
setManifestid(243403, "7526716281878074696", 103812044272)
addappid(243404, 1, "ec40a1599a6a24383428cb7f869d3db5331c3931312466a50c91598f4d32a789") --Main Macos Language Depot French BioShock Infinite
setManifestid(243404, "4300980429777935947", 196710489960)
addappid(243405, 1, "4f0916019f021835570186db8262fff2e5d4a895d97d63eeadda7c1973e5b7dd") --Main Macos Language Depot Italian BioShock Infinite
setManifestid(243405, "5142817714901292131", 154719703120)
addappid(243406, 1, "552035550df327039d3fdf8b23a245b6494d9abdccd93402dc2f4b01816f38bb") --Main Macos Language Depot German BioShock Infinite
setManifestid(243406, "7884534888533657015", 7003625368)
addappid(243407, 1, "c22c705666c7a208b7e2970442c5a00684aee4d3626f69cba6a802d517ac28ce") --Main Macos Language Depot Spanish BioShock Infinite
setManifestid(243407, "7943948738781491068", 154438969064)
addappid(243408, 1, "7f7217d00788590ee1aaa0a15e76a81ee857b5440c055a7b4b4d0c9b1f0077b1") --Main Macos Depot BioShock Infinite
setManifestid(243408, "5167305898510994234", 988849165984)
addappid(243410, 1, "6aeebd22fa6662c687b95286117f692ffd1e75bff070222a09f6ad51f871d8cb") --Main Macos Depot BioShock Infinite
setManifestid(243410, "6382481034026820513", 1898953949984)
--Dlcname BioShock Infinite: Clash in the Clouds
addappid(214930, 1, "aa8b3c8faa78cce6851d7dd9685d1d2711a807a1d6e3c5ad5a459dcef674fc1d") --Dlcname BioShock Infinite: Clash in the Clouds
setManifestid(214930, "6007107634313434151", 5327362176)
--Dlcname BioShock Infinite: Burial at Sea - Episode 1
addappid(214931, 1, "2d7da8ea513bce362d4a9409f8c57cd8a00d1408fa498906bc8f147d136a21dd") --Dlcname BioShock Infinite: Burial at Sea - Episode 1
setManifestid(214931, "456279142025267764", 6947240432)
addappid(243409, 1, "331b8a55b89962f1893ce6c6662aec0be0c8548835e41715db4cb649812acda0") --Dlc Macos Depot BioShock Infinite: Burial at Sea - Episode 1
setManifestid(243409, "5401207613780124140", 1082148965904)
--Dlcname BioShock Infinite: Burial at Sea - Episode 2
addappid(214932, 1, "4fff9cf8b90259de9daf4192cdcfb2f1c97e2855ff41103bdd7ec5dd8377b0d0") --Dlcname BioShock Infinite: Burial at Sea - Episode 2
setManifestid(214932, "6338001496100004241", 11039622368)
--Dlcname BioShock Infinite - Season Pass
addappid(214933, 1, "44c1c005c119f82c5061e5b33d222b77a0fdd289f3d2fbd9bfc08b2335fbb7d1") --Dlcname BioShock Infinite - Season Pass
setManifestid(214933, "413678731199728860", 1680)
--Dlcname BioShock Infinite - Upgrade Pack
addappid(214934, 1, "1db4f03b44c33f27deb84461973c041cf1eca83a8a29501dab93b32b8708a30f") --Dlcname BioShock Infinite - Upgrade Pack
setManifestid(214934, "8119747596882331492", 150081856)
--Dlcname BioShock Infinite - Comstock's China Broom Shotgun
addappid(214935, 1, "a8969a814cb18244570983c97c42885272f35f3bb2a6214b2258bb9cc79e6834") --Dlcname BioShock Infinite - Comstock's China Broom Shotgun
setManifestid(214935, "21127750251858478", 2144)
--Dlcname BioShock Infinite - Comstock's Bird's Eye Sniper Rifle
addappid(214936, 1, "ef3a38085080046306d4ad49d7774b5771de79836302beed36c73bcf2f477666") --Dlcname BioShock Infinite - Comstock's Bird's Eye Sniper Rifle
setManifestid(214936, "120716343951262089", 2224)
--Dlcname BioShock Infinite - Industrial Revolution Rewards Pack
addappid(214937, 1, "5b0b05e493e6f6c62978f856451a2d70b8a8ac76281e813999a5867af62cd49c") --Dlcname BioShock Infinite - Industrial Revolution Rewards Pack
setManifestid(214937, "344409664652722465", 2160)
--Dlcname Bioshock Infinite Season Pass Preorder
addappid(220159) --Dlcname Bioshock Infinite Season Pass Preorder
addappid(220160, 1, "ce371774a8165a158b0d0eec1f2233acf5c1df36a1232404a20e62b8e5d04558") --Dlc Windows Depot Bioshock Infinite Season Pass Preorder
--Dlcname BioShock Infinite - OSX CE Upgrade Pack
addappid(243411, 1, "fe9d896b8f0398a92c502530133c606a12ec071d3201af5d6ac18b1caa54d042") --Dlcname BioShock Infinite - OSX CE Upgrade Pack
setManifestid(243411, "546075434174591214", 1636417056)
--Dlcname BioShock Infinite - OSX Industrial Revolution
addappid(243412, 1, "df2be4c132a27f1ab6cda82442422174176508b5ffe8ddbe1381a6e2d23c9acf") --Dlcname BioShock Infinite - OSX Industrial Revolution
setManifestid(243412, "234153740723820394", 1440526584)
--Dlcname BioShock Infinite - OSX China Broom
addappid(243413, 1, "87966d88a887679493f7997aa4baef0e87238f79054e3dd38b0d74990ab1068a") --Dlcname BioShock Infinite - OSX China Broom
setManifestid(243413, "2000704046169958357", 1440892680)
--Dlcname BioShock Infinite - OSX Birds Eye
addappid(243414, 1, "6db7415fe5adc22039a1a9a2135f264ffda08bbdb7384ac142913188ab0e8e63") --Dlcname BioShock Infinite - OSX Birds Eye
setManifestid(243414, "2065256765358299491", 1440615784)
--Dlcname BioShock Infinite - OSX Season Pass
addappid(243415, 1, "c60e77f33fbf88818dbc6436990a391e7ce0ca68e0da170dc123a254a381abfd") --Dlcname BioShock Infinite - OSX Season Pass
setManifestid(243415, "19793821706264782", 1120451288)
--Share Depots
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b") --Share Windows Depot AppID 1523210
setManifestid(1523211, "5488617169383930545", 128)
addappid(220140) --Dlcname Bioshock Infinite - Industrial Revolution
addappid(2028850) --Dlcname Bioshock Infinite: Columbia's Finest