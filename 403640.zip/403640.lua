-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 403640.lua
--Gamename Dishonored 2
addappid(403640, 1, "3582d4e70768e1369678ee414c190052e50733358b6f9f86cd67e039d00be5a2") --Mainappid Dishonored 2
addappid(531331, 1, "35f48f15595210f9f136fcae710bc752de3578abcf7cf7d4d4cd746a7365841f") --Main Windows Depot Dishonored 2
setManifestid(531331, "2963729611279531718", 3813850064)
addappid(531332, 1, "114c03a6d0de557654950b295feb6207e81624b2b3ac305ff41953554bc1053a") --Main Windows Depot Dishonored 2
setManifestid(531332, "323898925697266621", 27137096352)
addappid(531333, 1, "fa13d85c1332888850c232c5fe0611ed89d8015c300e7af90e4fe02d75820894") --Main Windows Depot Dishonored 2
setManifestid(531333, "3073290089482226863", 5276901904)
addappid(531334, 1, "047f03056e35322bac5e476072f72205d1df9a0ef21d26b389bc06d7d943e3ad") --Main Windows Language Depot French Dishonored 2
setManifestid(531334, "1509347611848056991", 5298073344)
addappid(531335, 1, "854c87a23e557b35f530ccfa9300a3ffd79596205a696f12f2bbad771caf8716") --Main Windows Language Depot German Dishonored 2
setManifestid(531335, "8579808409801044094", 5393908736)
addappid(531336, 1, "fd11dbbc5b226de1bea8c35593b63810fc8d81211d166b3bb5bc1518a016b6da") --Main Windows Language Depot Italian Dishonored 2
setManifestid(531336, "4349704254291745693", 5489695392)
addappid(531337, 1, "6611c655d3ea1590eea5de2beb57bf8360abbdb2dfd7a01ffd1e508edc2482f0") --Main Windows Language Depot Spanish Dishonored 2
setManifestid(531337, "2261057237457725075", 5479946288)
addappid(531338, 1, "648a0738049d38c0395254aed4d642772a800b03ec6b1000ac4748411cb00970") --Main Windows Language Depot Spanish Dishonored 2
setManifestid(531338, "1596516164424361891", 5364356464)
addappid(531339, 1, "0704507f25342821cfae2d55fdfcc1ca9f4535e112b33a204c2cd621e558ee42") --Main Windows Language Depot Polish Dishonored 2
setManifestid(531339, "4011700633239816288", 5383603216)
addappid(531610, 1, "c0ce722ee82c73745c34464d065725464660e1b7271d7d953e5609969bc9bf45") --Main Windows Language Depot Russian Dishonored 2
setManifestid(531610, "7003273961168830067", 5487580320)
addappid(531611, 1, "6d08d6bdebc39be173564f0375fe938dc1a07edfcf367bebe4e732a7e11c4783") --Main Windows Language Depot Brazilian Dishonored 2
setManifestid(531611, "8314867122492112307", 5394137312)
addappid(531612, 1, "a11dc394ccd530c33cb40961da9e45e4c55d8007fe39273f164524873e104652") --Main Windows Language Depot Tchinese Dishonored 2
setManifestid(531612, "733220252853249822", 3603896992)
addappid(531613, 1, "13e4d61e4ed6adc86c9597f023e3bc1a53c5400802ea57aca8a36b77974369c9") --Main Windows Language Depot Japanese Dishonored 2
setManifestid(531613, "3244959933273624495", 5074952496)
addappid(531614, 1, "5df1167dc992c6a47481f360077cf8959da86e42b96e5507971e2992c9b4440a") --Main Windows Depot Dishonored 2
setManifestid(531614, "2793343286160593659", 148126720)
addappid(531615, 1, "6c3150443fc3d186d46ff8d8ab2d7b3bfc750e5743e8649c4ad5b11c65a88cc1") --Main Windows Depot Dishonored 2
setManifestid(531615, "6377159365043874055", 36556000)
--Share Depots
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228984, "2547553897526095397", 13436144)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(531330) --Dlcname AppID 531330
addtoken(531330, "4409454565398037283")