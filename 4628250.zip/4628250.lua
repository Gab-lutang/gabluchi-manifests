-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 4628250.lua
--Gamename How to Grow Your Sausage
addappid(4628250) --Mainappid How to Grow Your Sausage
addappid(4628251, 1, "00a6b32b8915752ec549ee937406a8978e51606b4110aba1873ba8e94498913a") --Main Windows Depot How to Grow Your Sausage
setManifestid(4628251, "1875883866761329717", 33045840)