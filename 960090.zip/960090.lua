-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 960090.lua
--Gamename Bloons TD 6
addappid(960090, 1, "2d7325ba593da3028ca6c850706586c422afc59de02f541c5d8e1a66fe3dd4e7") --Mainappid Bloons TD 6
addappid(960091, 1, "fa0fa5bda5003ddb011da9f8fd27d1680b2128487a5b03b752ad0772e0f52cd9") --Main Windows Depot Bloons TD 6
setManifestid(960091, "5003176145946154426", 2229955328)
addappid(960093, 1, "dd1593b861e9bd1297c007a48bc6c5d6e2a6a8b3ba8808d76534e20afe5012d6") --Main Macos Depot Bloons TD 6
setManifestid(960093, "6499293837119555960", 2267854816)
addappid(3377850) --Dlcname Bloons TD 6: Rogue Legends
addappid(4096360) --Dlcname Bloons TD 6: Frontier Legends