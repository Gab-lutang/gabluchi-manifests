-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 232770.lua
--Gamename POSTAL
addappid(232770, 1, "4b5b82be9798c581c3bed7925f88e33370948fd1f245e2b7d451e0599b156778") --Mainappid POSTAL
addappid(232771, 1, "0b3f5b747a013904638183986855f8b765d1b10511e01b47ab925bfde5e8e53f") --Main Windows Depot POSTAL
setManifestid(232771, "4856268982824038014", 268779200)
addappid(232772, 1, "b5903d85c4944c3fabf3e8dde5605f844dd40e486ef7e470469b8aed1e70ded2") --Main Linux Depot POSTAL
setManifestid(232772, "7418282084983807069", 263035792)
addappid(232773, 1, "45dc820b369b0449f1be5fe2eae2ba13e602422a26d9f2809a0c0dea00000ebb") --Main Macos Depot POSTAL
setManifestid(232773, "1739770070415342406", 262674944)