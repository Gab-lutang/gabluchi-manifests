-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1888160.lua
--Gamename ARMORED CORE™ VI FIRES OF RUBICON™
addappid(1888160, 1, "390e31da68aafb0ff69abe7db3bfc2f053495892b0cb9eb9b689bf692810d8d8") --Mainappid ARMORED CORE™ VI FIRES OF RUBICON™
addappid(1888161, 1, "2cbbae38e8fbb1cffbba8ca059d96e8b2ee29f77fdce9a9f47e666d333366341") --Main Windows Depot ARMORED CORE™ VI FIRES OF RUBICON™
setManifestid(1888161, "582364468276298215", 51758594368)
addappid(1888163, 1, "62410873212f70aa077827699bc4f786c4eefdd31e94201dfc9de87a63d491b8") --Main Windows Depot ARMORED CORE™ VI FIRES OF RUBICON™
setManifestid(1888163, "5961840280188243652", 46762992)
addappid(1888164, 1, "347a0ccf0383122fcfc3fc32a9e06d397e3b39da49a87e3404dae449bac0b8bf") --Main Windows Depot ARMORED CORE™ VI FIRES OF RUBICON™
setManifestid(1888164, "7986486217946675284", 46762992)
--Dlcname ARMORED CORE™ VI FIRES OF RUBICON™ Digital Artbook & Original Soundtrack
addappid(2308563, 1, "153004e3a9c40c3aece51551c6ffce884a22228a32c036de74ade86eb0be6576") --Dlcname ARMORED CORE™ VI FIRES OF RUBICON™ Digital Artbook & Original Soundtrack
setManifestid(2308563, "7372163286103826580", 574218000)
--Share Depots
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228988, "6645201662696499616", 22411856)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(2308560) --Dlcname ARMORED CORE™ VI FIRES OF RUBICON™ MELANDER C3 G13 Special Customization “TENDERFOOT”