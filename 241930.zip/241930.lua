-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 241930.lua
--Gamename Middle-earth™: Shadow of Mordor™
addappid(241930, 1, "81bfee6e10cd4a6371dd4ab1c957fe8eb3b3a4ae3188880d100fefad1930b528") --Mainappid Middle-earth™: Shadow of Mordor™
addappid(241931, 1, "7c4e1815a9ce8c6e129cc22c57358f675b3df4a786012fd586c279052d33a0a0") --Main Windows Depot Middle-earth™: Shadow of Mordor™
setManifestid(241931, "7071254921839907484", 45089516224)
addappid(241933, 1, "7dbae5566c776defb9c115939ae4ba023fc8107c3abe7e7d6efdf0fb14672b95") --Main Windows Depot Middle-earth™: Shadow of Mordor™
setManifestid(241933, "1038205350320663868", 35451106979112)
addappid(241934, 1, "512b0b2478b8bd7b62c88bcc0199069b43a9e214c4ba08832e2ff987232df6fa") --Main Macos Depot Middle-earth™: Shadow of Mordor™
setManifestid(241934, "5302237919585532242", 27240848)
addappid(241935, 1, "148a8f0fc1b2456ecf9d099cb8ebc65cbde52ff18838bad63f40fddfacbb7fa0") --Main Macos Depot Middle-earth™: Shadow of Mordor™
setManifestid(241935, "520325404024435612", 55673618448)
addappid(241936, 1, "ff60b24da22ffd4c82766eeb04dc102b5f32121866cca9b579fd5805ab056cc9") --Main Linux Depot Middle-earth™: Shadow of Mordor™
setManifestid(241936, "2267922015147902107", 109925616)
addappid(241937, 1, "f5736ec91929e07ad2b17dc652e729e55a94c61b4e065abbc25b81e19698a1ac") --Main Linux Depot Middle-earth™: Shadow of Mordor™
setManifestid(241937, "4045727426405588442", 44652980992)
addappid(318403, 1, "2916da63adf68fd4bbfd4bc864a36a6ef58872813c26f57a2441c334a01909e5") --Main Linux Depot Middle-earth™: Shadow of Mordor™
setManifestid(318403, "1194013520339598619", 743776)
addtoken(311670, "5867957274117655006")
addappid(311670, 1, "86d46a5a860445a99e60b022176f9589f94501f90898efdbd49a42a0f5dbcb12") --Dlcname AppID 311670
setManifestid(311670, "1812801919891248732", 2297569843618)
addappid(318394, 1, "0f3c5ba64416d5b72037ee55095fc27d046781338e7e4f600817f67bcbd321f9") --Dlc Macos Depot AppID 311670
setManifestid(318394, "565062480437948453", 4335187872)
addappid(318395, 1, "3ac1282385d9b5a5c08e2241c709299467bd8e5680825700c0da4717bf1720ab") --Dlc Linux Depot AppID 311670
setManifestid(318395, "5828227158235581202", 4338670048)
--Dlcname Middle-earth: Shadow of Mordor - Captain of the Watch Character Skin
addtoken(313370, "1168154938391366305")
addappid(313370, 1, "64dbfc5f47d8c9c95fbb59671f01927bbbc8ae72124036ac3b1d9d107d1f15f8") --Dlcname Middle-earth: Shadow of Mordor - Captain of the Watch Character Skin
addappid(241946, 1, "13b8389b427ccfdd1515d9a136bcd35fd4a9bd0693e03d179806c61f7eac040b") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Captain of the Watch Character Skin
setManifestid(241946, "150797972647156206", 160)
addappid(241947, 1, "55a92ce00f8d357d1e0075e1058629eed90d4791af6a77a255b06dca3cf94828") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Captain of the Watch Character Skin
setManifestid(241947, "241342566741189442", 160)
setManifestid(313370, "6785743772532095830", 256)
--Dlcname Middle-earth: Shadow of Mordor - The Dark Ranger Character Skin
addtoken(313371, "16085996130026299492")
addappid(313371, 1, "396aacbf373726c368062115242ff1ea4cc119d62ab1eed1deb0abcb2a128eea") --Dlcname Middle-earth: Shadow of Mordor - The Dark Ranger Character Skin
addappid(241944, 1, "bb1a217816b58973f791d47a1f92edac0daaf1ec58f041c88195dd4b794bc2fe") --Dlc Macos Depot Middle-earth: Shadow of Mordor - The Dark Ranger Character Skin
setManifestid(241944, "451342747814248512", 64)
addappid(241945, 1, "e7265d761fda61321de8e7cdf8d6659d2464a583b22b5ec09b4a89e40e73485f") --Dlc Linux Depot Middle-earth: Shadow of Mordor - The Dark Ranger Character Skin
setManifestid(241945, "79991797313161407", 64)
setManifestid(313371, "2673701849941391340", 160)
--Dlcname Middle-earth: Shadow of Mordor - Test of Power
addtoken(313372, "399986386970371985")
addappid(313372, 1, "67191741a00650fb214af4967537ee704bde35dbf0e77a58381cbd8ba7bebbfb") --Dlcname Middle-earth: Shadow of Mordor - Test of Power
addappid(241940, 1, "ca88f001d4c03de73c1854355360d32ca1cffd5226dbdaee82982584589b5956") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Test of Power
setManifestid(241940, "198551078063880808", 144)
addappid(241941, 1, "91117e3ef5a014c5f65771b1682fa71a0cc4562b4de96a94ae64b8f2f072f8f5") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Test of Power
setManifestid(241941, "505888075535897411", 144)
setManifestid(313372, "4150298883702055089", 65539960)
--Dlcname Middle-earth: Shadow of Mordor - Hidden Blade Rune
addtoken(313373, "13490608987146641089")
addappid(313373, 1, "18b28cd0c80c234a19313ebeb94576185007c2d591a8fd46256ac28c17badf62") --Dlcname Middle-earth: Shadow of Mordor - Hidden Blade Rune
setManifestid(313373, "2100538871572823223", 160)
addappid(313379, 1, "d1d79004cc5cbdd2c03d39d48e74f4d35773beecc8892c8234d6e57db86c5294") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Hidden Blade Rune
setManifestid(313379, "88504332424598571", 144)
addappid(313382, 1, "c01c9230f445d96de065a4b91b30690caa2f41210bce6d27cdf803f003cbce4f") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Hidden Blade Rune
setManifestid(313382, "226843953076485267", 144)
--Dlcname Middle-earth: Shadow of Mordor - Deadly Archer Rune
addtoken(313374, "8213909035351686530")
addappid(313374, 1, "600902dd5d28afaa677adfa911b98c93a84a0d8752e64cdd823e382d76b25c19") --Dlcname Middle-earth: Shadow of Mordor - Deadly Archer Rune
addappid(311679, 1, "35de20988bc6b3e4a89edab7c6722cba9237611443937564e19d087883abb27d") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Deadly Archer Rune
setManifestid(311679, "126248704430895380", 64)
setManifestid(313374, "7782708720424048724", 160)
addappid(313376, 1, "7ae25177411ddf63ee8db5f6c130d3d5c5f0143984fdd7f115425ff5b3322c18") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Deadly Archer Rune
setManifestid(313376, "93934994673932038", 64)
--Dlcname Middle-earth: Shadow of Mordor - Flame of Anor Rune
addtoken(313375, "2432580564690961838")
addappid(313375, 1, "b5c547f8cc57ef1d1d5f2afccf3a2ecde0738bc2446dd6c885e4676812007162") --Dlcname Middle-earth: Shadow of Mordor - Flame of Anor Rune
addappid(311673, 1, "acd2aa7c66e7d771bb8a2dcb9782c25661ae6a302412295c4dbb6927ad03c1ee") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Flame of Anor Rune
setManifestid(311673, "761033414882186283", 64)
addappid(311674, 1, "cdcc0d287207795b21f8f8632a4e12e8ab797e7d74f4599e8d7b5804933f665e") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Flame of Anor Rune
setManifestid(311674, "251649049178337622", 64)
setManifestid(313375, "3626747238116382439", 160)
--Dlcname Middle-earth: Shadow of Mordor - Orc Slayer Rune
addtoken(313380, "17000693143313379839")
addappid(313380, 1, "19b93aa0d27186355edc00d7edbb02ab3ceeed3be032e443750bc083943e9f14") --Dlcname Middle-earth: Shadow of Mordor - Orc Slayer Rune
addappid(241948, 1, "a2e5e4e8fa0cc99d81902c2a8ad5c9b50d6c83217caeb1794f752ea1b83c8d17") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Orc Slayer Rune
setManifestid(241948, "132684409081226428", 64)
addappid(241949, 1, "cd3004efcbae9251008e44d06bca110adf9690fef35471e0170a003545e54450") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Orc Slayer Rune
setManifestid(241949, "226869915232437372", 64)
setManifestid(313380, "324148619083483478", 160)
--Dlcname Middle-earth: Shadow of Mordor - Rising Storm Rune
addappid(313381, 1, "74d7ef124f8edc0b7ca06e0253555499607382af0673f67063704cb85ed92322") --Dlcname Middle-earth: Shadow of Mordor - Rising Storm Rune
setManifestid(313381, "1897900014090252580", 160)
addappid(313383, 1, "b8ac5cb133ccbdf703db2953886742048007a6bb8169593b9bcecf29458e0182") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Rising Storm Rune
setManifestid(313383, "176883524697537291", 144)
addappid(313384, 1, "84de28113086b1f7b8c07d39ee90cac5fd13a913730d296637e303a22098850c") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Rising Storm Rune
setManifestid(313384, "251667965605689736", 144)
--Dlcname Middle-earth: Shadow of Mordor - Lord of the Hunt
addappid(318390, 1, "f18dd17b47f664b19a525f12ae27c04597a77da9c5e60af27bbfd6e36f61132b") --Dlcname Middle-earth: Shadow of Mordor - Lord of the Hunt
addappid(311671, 1, "894fc089aa16f117bf74a359e42ac37cfbf8776d825f846479e4bc667cddd72f") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Lord of the Hunt
setManifestid(311671, "6290040308489434", 160)
addappid(311672, 1, "4f65ebf2c254f714fabb08a1190afa47a339d49d84c999729f01c3a9c278dbd3") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Lord of the Hunt
setManifestid(311672, "408242152678903232", 160)
setManifestid(318390, "2244672915508740651", 256)
addtoken(318400, "16066113702663158462")
addappid(318400, 1, "0f11f5a2755926dd0ed5cbfcf541afd9ecf6aa8f387462b2ffd02ea8c15bf042") --Dlcname AppID 318400
addappid(318392, 1, "abbc7a1ab617325f953a204b48f4fb550e174891583d4716a7cc14231249f4d2") --Dlc Macos Depot AppID 318400
setManifestid(318392, "327527746890158923", 144)
addappid(318393, 1, "08c0bc109ac2ff714b0263b4a6d28665b17efdc0d81381369b995dd707c555e8") --Dlc Linux Depot AppID 318400
setManifestid(318393, "157678416887926708", 144)
setManifestid(318400, "7073419462418481756", 256)
--Dlcname Middle-earth: Shadow of Mordor - Test of Wisdom
addtoken(318401, "17868683448414809077")
addappid(318401, 1, "e1cfa1ac581fd6418d817b2f52c7dbc4a87600343b44a880e1214ac720b7120d") --Dlcname Middle-earth: Shadow of Mordor - Test of Wisdom
addappid(313387, 1, "610d0a7b44ee949097f9b27c5a057f9276600f607766b6d3fa5deb3fd84de9c7") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Test of Wisdom
setManifestid(313387, "337246302042226792", 144)
addappid(313388, 1, "42b5fb61463dbcf3569c25ac35e15024dbdca2533bc1616480484624f8a72040") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Test of Wisdom
setManifestid(313388, "397486373878278847", 144)
setManifestid(318401, "7582280970679003090", 256)
--Dlcname Middle-earth: Shadow of Mordor - Endless Challenge
addtoken(318402, "16375660157213751064")
addappid(318402, 1, "9c5b312c5d18010da3a6e0b8c4cc0fadfa7a0dd5fec7a9c6da356e7c3df147a0") --Dlcname Middle-earth: Shadow of Mordor - Endless Challenge
addappid(313385, 1, "8d448889ed2bd3e02527c8352d9bdb92422e930c2d2ba3dc28014c2e45fccff3") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Endless Challenge
setManifestid(313385, "38893109541982664", 144)
addappid(313386, 1, "b9f78acfd93621452fc9797b6db58bc47c69b8c2b9745a36e025d29656654b57") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Endless Challenge
setManifestid(313386, "373364530690308125", 144)
setManifestid(318402, "1501748316290578442", 256)
--Dlcname Middle-earth: Shadow of Mordor - Berserks Warband
addtoken(318410, "10771226610455739711")
addappid(318410, 1, "976d70058cca25fa12a90dbfb259840f6abd70f585e51e9c44846d471a68af46") --Dlcname Middle-earth: Shadow of Mordor - Berserks Warband
addappid(311677, 1, "f4a8039cd205ce65479df355d2ae36d352bdd1c036b9ea85fa2cd63f3e70f33f") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Berserks Warband
setManifestid(311677, "939564319737479965", 144)
addappid(311678, 1, "7682c4646e432fd195c75022cda9e7d0de3ebc667b4c36eb635d02a85cf37850") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Berserks Warband
setManifestid(311678, "332407454491908780", 144)
setManifestid(318410, "7721744647487988279", 240)
--Dlcname Middle-earth: Shadow of Mordor - Blood Hunters Warband
addtoken(318411, "13036980711745789694")
addappid(318411, 1, "66229f379ce074a72fe4ce52493ef1f7340b5e3e8b1f74e9f393dd00454266cd") --Dlcname Middle-earth: Shadow of Mordor - Blood Hunters Warband
addappid(241942, 1, "fd28f06ff22d6a8cb00f437c524a7aefb8dfaa0a5a55ae070562fdd9ead1f49e") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Blood Hunters Warband
setManifestid(241942, "37039354161770609", 160)
addappid(241943, 1, "334bf0e38723bbcbcd1782cca799201a8525b32e773df100f133000a00993428") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Blood Hunters Warband
setManifestid(241943, "143519756273469305", 160)
setManifestid(318411, "7570495842780458661", 256)
--Dlcname Middle-earth: Shadow of Mordor - Skull Crushers Warband
addappid(318412, 1, "53eb6d34a7d885fad1128f7e1c45632ac0f912c96af24b3336d054b46227e7ba") --Dlcname Middle-earth: Shadow of Mordor - Skull Crushers Warband
addappid(313377, 1, "cc6cc4c393f24f1c6ca23ee1928e1510a7d94ee1eac919b8b21bd4c3ded3c398") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Skull Crushers Warband
setManifestid(313377, "72984406239910946", 144)
addappid(313378, 1, "511baa3d7a6ba0ffebb76a56f446bf19e9437532c3aa48c80eb1f0827caaf915") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Skull Crushers Warband
setManifestid(313378, "77374347280954330", 144)
setManifestid(318412, "7896682710253848809", 240)
addtoken(318413, "3288353559581157825")
addappid(318413, 1, "697a4af46b8e857bc47b83d088e03a374a5a7ec78554d070e1180df6aca783b0") --Dlcname AppID 318413
addappid(318396, 1, "e83d5eab59596aa83748f3e4df5641b36fabbb8f2ebe4691bc8131ccf9b8cd9f") --Dlc Macos Depot AppID 318413
setManifestid(318396, "198872129776188125", 144)
addappid(318397, 1, "cb5521f4890279cc126b76346f80eddd23249e326e066b00a4b1968c31e5374e") --Dlc Linux Depot AppID 318413
setManifestid(318397, "836722487519099266", 144)
setManifestid(318413, "982538916912193001", 240)
--Dlcname Middle-earth: Shadow of Mordor - Flesh Burners Warband
addtoken(318414, "2887865160447118272")
addappid(318414, 1, "79a0b1099bdaf94927a1490acd1bfdfc5256fa7de53a97df17af2675c088e2ae") --Dlcname Middle-earth: Shadow of Mordor - Flesh Burners Warband
addappid(311675, 1, "ff4f3a1c90615ce4fa644caa962399538e1db17c2fb52d95f4808cf1a1635978") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Flesh Burners Warband
setManifestid(311675, "81531446865821194", 160)
addappid(311676, 1, "6433f470fb79bf0060885d7c3d1f5647741a4773e3957702bcb1fdc7a19a4a10") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Flesh Burners Warband
setManifestid(311676, "1189157360305958631", 160)
setManifestid(318414, "8828261464440646425", 256)
--Dlcname Middle-earth: Shadow of Mordor - Bright Lord
addappid(318420, 1, "a1fc909f24c5c877f03b3f7894296d05f1e65b2f46962b68bf9068536644d691") --Dlcname Middle-earth: Shadow of Mordor - Bright Lord
addappid(241938, 1, "2343c752576a4c6ed2fd261344d398ad8b77935ee5824433b2d9da483c88f1a7") --Dlc Macos Depot Middle-earth: Shadow of Mordor - Bright Lord
setManifestid(241938, "99144665449347834", 160)
addappid(241939, 1, "b92b8c405edf8a193f73cf4e45102d724d978ec2b375dcf9c28746f6403e3748") --Dlc Linux Depot Middle-earth: Shadow of Mordor - Bright Lord
setManifestid(241939, "432970632182559681", 160)
setManifestid(318420, "6342813387448459939", 60100824)
addtoken(322060, "15372843753691751540")
addappid(322060, 1, "376d39c6e535b3b86e978a7279a5a9c17b71d76397737dbc992212e5e270ad12") --Dlcname AppID 322060
addappid(313389, 1, "6e7992a6c641ac13357ec32016401cc24fbfa4a75130ae5a02e0e5f805be2d1a") --Dlc Macos Depot AppID 322060
setManifestid(313389, "275900152902156583", 144)
addappid(318391, 1, "1eabd1b3848ac7c84dec1c160504edb5b8968dda8ecacd1ffabd5ee25aac6ad4") --Dlc Linux Depot AppID 322060
setManifestid(318391, "218631542842170868", 144)
setManifestid(322060, "1356036462370594379", 5)
addappid(322061, 1, "f00a1b7fa94eef4ecd6199fed1e147dd745d135bdabfef48ad65bf7003441142") --Dlcname AppID 322061
addappid(318398, 1, "f3c99b6d57b8981f4b23120cc19795e6e721179c1c2bb2a03085a7b0f54dd967") --Dlc Macos Depot AppID 322061
setManifestid(318398, "2145919411303746835", 144)
addappid(318399, 1, "1ebfcf6d1b89d94279f67bb2568004d748a69f7a12c2640f040c8f2a29837969") --Dlc Linux Depot AppID 322061
setManifestid(318399, "388872846429289073", 144)
setManifestid(322061, "6740177555138261104", 256)
--Share Depots
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
--Missing Dlcs
--Dlcname Middle-earth: Shadow of Mordor - GOTY Edition Upgrade
addappid(319360) --Dlcname AppID 319360
addtoken(319360, "6521601987940572899")
addappid(319361) --Dlcname AppID 319361
addtoken(319361, "5948478596417424934")