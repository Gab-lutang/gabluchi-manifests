-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 498240.lua
--Gamename Batman - The Telltale Series
addappid(498240, 1, "c69d99e9144f803ce98bff690a9e5d968676323eda87869ae3144d5472868b50") --Mainappid Batman - The Telltale Series
addappid(498241, 1, "6c3bfd45e0c0888d53d77be4d8c5f9f9ac745bbfbc61b3f81c3a4b2ff15390d1") --Main Windows Depot Batman - The Telltale Series
setManifestid(498241, "8351183795319616463", 2711036544)
addappid(498242, 1, "e8bb08fdbe95c73d631f1b80c148bf0c452bd9e5a242e7b9805158c474a7c37f") --Main Macos Depot Batman - The Telltale Series
setManifestid(498242, "2113006490179306366", 2861715104)
addappid(498243, 1, "118d1faeacd0f5fa58ff309617486561f6a983c9922cb1d835c1ab00b5dc2ac2") --Main Windows Depot Batman - The Telltale Series
setManifestid(498243, "3082147466116147028", 16048)
addappid(498245, 1, "ec94676efe67a10c81d467fb50d858aaa2a20a142262f7389bb1e15a5203aafe") --Main Windows Depot Batman - The Telltale Series
setManifestid(498245, "8579920043796825481", 2788853088)
addappid(498247, 1, "30a00f813ae353e6c441aa69c45657666a025ffc3c496263d9460d56f3366394") --Main Windows Depot Batman - The Telltale Series
setManifestid(498247, "6119477914450071581", 2687868768)
addappid(498249, 1, "637bcbca7f69f1156553179e06a46a6069b5c26ab446c9e008519f04825960e5") --Main Windows Depot Batman - The Telltale Series
setManifestid(498249, "3804650890122010285", 2693324480)
addappid(551921, 1, "280a2f38a432603d9fd38ab47042cb8ea9ba0106122810b0567d73a53af795c0") --Main Windows Depot Batman - The Telltale Series
setManifestid(551921, "4813989855450898323", 2920357936)
addappid(551923, 1, "b96b7801bbd84a7e9b67feb3c387cebfb97fa4bd8dcd144d419f16cdadd1bd5b") --Main Windows Depot Batman - The Telltale Series
setManifestid(551923, "8446626364703807665", 76982400)
--Dlcname Batman Noir
addappid(1182000, 1, "f4113e2f7553cb4c80de09e3e18df32b995c39b5ff085a2ac76fc0104e16841d") --Dlcname Batman Noir
setManifestid(1182000, "6189248178580764921", 6388706832)
--Share Depots
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228986, "8782296191957114623", 23045488)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)