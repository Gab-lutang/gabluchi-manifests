-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 356190.lua
--Gamename Middle-earth™: Shadow of War™
addappid(356190, 1, "cfb174ccd74f7b90edb72f7a7daf8455d7e63a0519c17ca542f92346b6407cc3") --Mainappid Middle-earth™: Shadow of War™
addappid(356191, 1, "260abd037eed772bf36b780e13d94ab075cc04f2f80fa4f3e39b907c037892ae") --Main Windows Depot Middle-earth™: Shadow of War™
setManifestid(356191, "8564100506276968089", 100738858464)
--Dlcname The Desolation of Mordor Story Expansion
addappid(533110, 1, "acd25e0fcc2aac0e70af4b8df205e6a8e8258823362cc5279c0aeaf96c3bf0b3") --Dlcname The Desolation of Mordor Story Expansion
setManifestid(533110, "3372049505845498644", 1227925808)
--Dlcname Slaughter Tribe Nemesis Expansion
addappid(561630, 1, "09a49c880919eba4606ada3fa04063e48fc7193ce75f44f48c2c129aa7ab5640") --Dlcname Slaughter Tribe Nemesis Expansion
--Dlcname Outlaw Tribe Nemesis Expansion
addappid(561631, 1, "67156c88820fecc9fcf6f1a38178224e04f6bdc15f760e38da7383cca1c36dfc") --Dlcname Outlaw Tribe Nemesis Expansion
--Dlcname The Blade of Galadriel Story Expansion
addappid(561650, 1, "ad42072d011a1042b773c99fa9967be93667a884ce3c2f13cdc7d724f7f97276") --Dlcname The Blade of Galadriel Story Expansion
setManifestid(561650, "6461386082584988817", 1261693200)
--Dlcname Middle-earth™: Shadow of War™ High Resolution Texture Pack
addappid(561950, 1, "b5325bbdf2c67fac37d9cffdd972e7306630fa3ce77980cca227726d314ed78d") --Dlcname Middle-earth™: Shadow of War™ High Resolution Texture Pack
setManifestid(561950, "1157446448995806717", 14192505776)
--Dlcname Sword Of Dominion
addappid(580090, 1, "84040aa240f391e0f08955bd4fad4c8b2112b184096cfa4d3e4c8efc4817627f") --Dlcname Sword Of Dominion
--Dlcname Champions of War
addappid(580500, 1, "1dbc00e2ba75de947c6169c75239795df9bf4e29e9af262472b0f995da514c37") --Dlcname Champions of War
--Dlcname Standard Content
addappid(581770, 1, "32613880936bfbd9b552e6cd3132cf688cdc4ac262e0a3c720ad8086b75dd431") --Dlcname Standard Content
--Dlcname Gold Content
addappid(581772, 1, "47abb4b996cedd89f47c4f34bbe5233c2126d4f36730d1dac1f075a6454ba81c") --Dlcname Gold Content
--Dlcname Middle-earth™: Shadow of War™ Starter Bundle
addappid(629580, 1, "215198418d5878e37594113fe60b312ce5089fff3c27950385deb6905379b9b9") --Dlcname Middle-earth™: Shadow of War™ Starter Bundle
--Dlcname Middle-earth™: Shadow of War™ 4K Cinematic Pack
addappid(666840, 1, "d25e071b5d2da2b43e96908d43ebd3364908a5f141731e9482e79c0cf621344f") --Dlcname Middle-earth™: Shadow of War™ 4K Cinematic Pack
setManifestid(666840, "3687123933403575662", 27297945328)
--Dlcname Expansion Content
addappid(740710, 1, "94cba1367140aaea62e7aec8f40bbd558a393d04980d911a5fbb6082d6ac0cdb") --Dlcname Expansion Content
--Share Depots
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228986, "8782296191957114623", 23045488)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(716270) --Dlcname Middle-earth™: Shadow of War™ Expansion Pass
addappid(784070) --Dlcname Story Expansion Pass
--Missing Dlcs
--Dlcname Silver Content
--Dlcname Mithril Content
--Dlcname Story Pass Content
--Dlcname Middle-earth: Shadow of War Definitive Edition Content
addappid(580030) --Dlcname AppID 580030