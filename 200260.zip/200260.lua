-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 200260.lua
--Gamename Batman: Arkham City - Game of the Year Edition
addappid(200260, 1, "41cfb7d53707290001fe02f3e4558162e1a70057534aad539684efb7a60b28cc") --Mainappid Batman: Arkham City - Game of the Year Edition
addappid(200261, 1, "019a5f25f2e8f8f5af0e2abd4a378d118584220629f3696c764feea17a10e7df") --Main Windows Depot Batman: Arkham City - Game of the Year Edition
setManifestid(200261, "957853014295671009", 0)
addappid(200262, 1, "5ce8e1ff931612a6ad759d0dc3b9e17792f76ef2f68617a342f8f7ca2878334f") --Main Macos Depot Batman: Arkham City - Game of the Year Edition
setManifestid(200262, "7845728011859274564", 12421752016)
addappid(200263, 1, "b4deb67bcf16c9789ca98333b2468a7855c1d0b5666831512931c0ba7fbec342") --Main Macos Depot Batman: Arkham City - Game of the Year Edition
setManifestid(200263, "4940815151499122323", 86405072)
addappid(200264, 1, "efdd039029c3029efa403065598ec995138b93e3397c229fc701b9ec382518cc") --Main Macos Language Depot English Batman: Arkham City - Game of the Year Edition
setManifestid(200264, "387377931563640160", 0)
addappid(200265, 1, "9181b86acfee5b9a04dc9cdb91a3b718d7270088f5b8ad38c0546308b6b74bfc") --Main Macos Language Depot French Batman: Arkham City - Game of the Year Edition
setManifestid(200265, "1556860923130685654", 0)
addappid(200266, 1, "1d7278a2f37cea578f87ae627b04c1243a1fae53a08c30e61a8480220f2fcb7e") --Main Macos Language Depot German Batman: Arkham City - Game of the Year Edition
setManifestid(200266, "406813562658710105", 0)
addappid(200267, 1, "0ffd19248ba97019cfa054a9d313a0c49783c79486cfefa7adb1ae7046a585ad") --Main Macos Language Depot Italian Batman: Arkham City - Game of the Year Edition
setManifestid(200267, "1530229855874547766", 0)
addappid(200268, 1, "218ea6bab509c53b1b4aca532ba76b6333e507c8767eb12ee8941ffc317368c4") --Main Macos Language Depot Spanish Batman: Arkham City - Game of the Year Edition
setManifestid(200268, "425136602149417750", 0)
addappid(200269, 1, "5692d822f135fbb0956387d55f8379f18ffc8184a69ed34a5f48f1b6b992ca70") --Main Macos Language Depot Polish Batman: Arkham City - Game of the Year Edition
setManifestid(200269, "4553205993270337121", 0)
addappid(200270, 1, "77e1035ff98a181969f9af3ebe24fe887edc2e508c33a3b77698fd553ce2b94a") --Main Macos Language Depot Brazilian Batman: Arkham City - Game of the Year Edition
setManifestid(200270, "827746602157973325", 0)
addappid(200271, 1, "650fc34b13a3aed6a2876dc2f60142823f6f87481286bab0632c11add439e722") --Main Macos Language Depot Russian Batman: Arkham City - Game of the Year Edition
setManifestid(200271, "407262115261230492", 0)
addappid(200272, 1, "d9547d1756b041183d7b9ba73e9d32a76915b139426077e696256357c2cb39a5") --Main Macos Language Depot Polish Batman: Arkham City - Game of the Year Edition
setManifestid(200272, "2232671537466003555", 0)