-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 239030.lua
--Gamename Papers, Please
addappid(239030, 1, "b93c53757176c0671ee1d6898fb83453742bd99ebe1551a1e7bc194d703ca252") --Mainappid Papers, Please
addappid(239031, 1, "0d3295b4cb4eb5ac0f3bc40478fb875d708b49b80617988ba1751e471bf46253") --Main Windows Depot Papers, Please
setManifestid(239031, "6905656874083880948", 35743872)
addappid(239032, 1, "43355768d8e7be51631d0390e4d71e6ac233bd7e2803b10fc2e5c93cae960a88") --Main Macos Depot Papers, Please
setManifestid(239032, "6188834483198805795", 44336672)
addappid(239033, 1, "069690842a264d22828b8465895a14b83467482ab765dfcdcb9da6dd25e292b6") --Main Linux Depot Papers, Please
setManifestid(239033, "7577473921595950709", 35766928)