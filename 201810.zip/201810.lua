-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 201810.lua
--Gamename Wolfenstein: The New Order
addappid(201810, 1, "6dfaef0cf35b15403d1bd15f88909b330ae83c471bb2ee22d937bddde19b1043") --Mainappid Wolfenstein: The New Order
addappid(201811, 1, "d254eedc6a277b20e3dd87bdc8877882fa2aa9443cfd4d5169597ca24923bff2") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201811, "4483959248306290042", 0)
addappid(201812, 1, "5cceb657f3da6258c032aa8ada8d86274fa8c5d9cc37a06b9c41e10e9c881727") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201812, "6190769423243292568", 0)
addappid(201813, 1, "84284dbd7c8c9dcad82c0f65dce2828ce06117045f5df674727dbc47e59439b1") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201813, "4198771529530767213", 0)
addappid(201814, 1, "850746833329899a464019418dc2129117c56cd37d22886f37ba155b02ec0bc4") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201814, "7419404030065740466", 0)
addappid(201815, 1, "a67b5b0f70f9930f5bf5ef43b4c47a98edc934e8ee71cfbc1ef1e5cfe095326e") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201815, "6372228485140000019", 0)
addappid(201816, 1, "cfb9994d4359e8d2644cd703a8635d68516e901cadd3ee49d109b872b5f77de9") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201816, "2564310353164314558", 0)
addappid(201817, 1, "9aa6b86c00a585567a3b780191f32ebe6910ffb3b4729eb7baa76ed8214c82b4") --Main Windows Language Depot Japanese Wolfenstein: The New Order
setManifestid(201817, "8962022361405031159", 0)
addappid(201818, 1, "9f693dc90add88bb4ddfa91b9be3bf594f52ba537040ea1be398a6e03f38bda5") --Main Windows Language Depot Japanese Wolfenstein: The New Order
setManifestid(201818, "8452286535441547273", 0)
addappid(201819, 1, "a391348b69b811d538e4541c335fd41e5f9603a07ca256a20c43a00a878a66b0") --Main Windows Depot Wolfenstein: The New Order
setManifestid(201819, "393115506002332855", 0)
addappid(201820, 1, "f20cee9d75e2f455cfc02f26304335e7c2e067f1ad8b517751cad7239bdcda72") --Main Windows Language Depot French Wolfenstein: The New Order
setManifestid(201820, "4853410428376415487", 0)
addappid(201821, 1, "b8d781a49b3cba8e81ee2d1bc1853b0202e9da232e71b6e7770c8acc826c0a8a") --Main Windows Language Depot Spanish Wolfenstein: The New Order
setManifestid(201821, "2842838024493110567", 0)
addappid(201822, 1, "ea3018204bab30951d6996ec98a6912fa73679ad57b312bbe65eb342a4a73735") --Main Windows Language Depot Italian Wolfenstein: The New Order
setManifestid(201822, "7359381863497489497", 0)
addappid(201823, 1, "33a582df83b02a0a791bc0c1009b71a19748bcdcd51b79f204246027984381a9") --Main Windows Language Depot Japanese Wolfenstein: The New Order
setManifestid(201823, "8971042541874667620", 0)
addappid(201824, 1, "f1caa0e4a7f205fe9f94cdbc268df210ba3e846986024e1d9d0384b0f8bcc969") --Main Windows Language Depot Japanese Wolfenstein: The New Order
setManifestid(201824, "4057511848496321450", 0)
addappid(426820, 1, "b84790788f504d95fae914aff7d0ff39ac4e2ec66bb92f31f8f11675599a2c47") --Main Windows Depot Wolfenstein: The New Order
setManifestid(426820, "8948924963522164096", 93591248)
--Share Depots
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228982, "6413394087650432851", 9650016)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)