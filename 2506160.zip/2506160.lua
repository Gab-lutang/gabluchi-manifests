-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 2506160.lua
--Gamename Fears to Fathom - Ironbark Lookout
addappid(2506160) --Mainappid Fears to Fathom - Ironbark Lookout
addappid(2506161, 1, "21ca9f80277ec51e1e063ad48d39eb22f37081c9034ab900704dde1986b4806e") --Main Windows Depot Fears to Fathom - Ironbark Lookout
setManifestid(2506161, "8875520618792936983", 1509456304)