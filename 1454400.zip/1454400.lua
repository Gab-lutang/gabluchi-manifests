-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1454400.lua
--Gamename Cookie Clicker
addappid(1454400, 1, "bee35fc41b9a4f44f4d1017924dcc20a9241b2755b02a3178baee78dc2f49ab9") --Mainappid Cookie Clicker
addappid(1454401, 1, "dc8be6e8bb8cf9a7d3f548fe759eb532def1c3d380deece391d81dafa6c96e67") --Main Windows/Linux Depot Cookie Clicker
setManifestid(1454401, "5817090063491018460", 100900736)
addappid(1454402, 1, "39c00dfd8ff729f8012400b55fc6d55b1c21b5ee2b012fe72a6c33b5b5ec176b") --Main Macos Depot Cookie Clicker
setManifestid(1454402, "1124352571317316090", 156932720)