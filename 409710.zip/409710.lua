-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 409710.lua
--Gamename BioShock™ Remastered
addappid(409710, 1, "95e9896bb1fce724f49f9fa3c5772e07511be5bb723ca3e733a7b1748d4b2832") --Mainappid BioShock™ Remastered
addappid(409711, 1, "bd65f2941dcca212b3647a1ef093d35794fba9e1874789af52296830e5753e74") --Main Windows Depot BioShock™ Remastered
setManifestid(409711, "2054297745673814910", 13089972160)
addappid(409712, 1, "861974161720d0447dbcaf161218365bb3dade2b264871a9dd9b8a3fb10377e4") --Main Macos Depot BioShock™ Remastered
setManifestid(409712, "5589255365212164825", 75286496)
addappid(409713, 1, "5726f9ecc0a96c7591d3bcadf845fa8dcfcc84a94b22740f7029a46a64297544") --Main Macos Depot BioShock™ Remastered
setManifestid(409713, "4316661907019228653", 17726350336)
--Share Depots
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228984, "2547553897526095397", 13436144)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228988, "6645201662696499616", 22411856)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(1523211, 1, "6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b") --Share Windows Depot AppID 1523210
setManifestid(1523211, "5488617169383930545", 128)