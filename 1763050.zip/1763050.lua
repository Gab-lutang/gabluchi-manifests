-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1763050.lua
--Gamename Fears to Fathom - Norwood Hitchhike
addappid(1763050) --Mainappid Fears to Fathom - Norwood Hitchhike
addappid(1763051, 1, "5506e30e0f825869abc207dee41bc99b82c73ca6939272e56149077f80618421") --Main Windows Depot Fears to Fathom - Norwood Hitchhike
setManifestid(1763051, "3854526276740594378", 2801276912)