-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 205100.lua
--Gamename Dishonored
addappid(205100, 1, "9d56260f4859e162e791448c03ebccaef27ea5caf7cb58d2d0df3d17942a3208") --Mainappid Dishonored
addappid(205101, 1, "42107f3f2d8fde4d980e3de5a3b6a9548497675b97fb5be88e578964c24991ce") --Main Windows Depot Dishonored
setManifestid(205101, "3682254645125751955", 0)
addappid(205102, 1, "1e60f542dfd33d42eef0d45965f5c7a19a6949eb1ec97f399700dbc3c85d7dc8") --Main Windows Language Depot English Dishonored
setManifestid(205102, "955788823064539748", 0)
addappid(205103, 1, "ed518fd42aef448c1043fe291a80632e85207242b8d4d18f7f51a4a80bc644aa") --Main Windows Language Depot French Dishonored
setManifestid(205103, "652007769989793428", 0)
addappid(205104, 1, "0cf761fe1cf22a43fa7daba45af5368cd11e40fd5e5f8cff7a154f2cf7434090") --Main Windows Language Depot Italian Dishonored
setManifestid(205104, "5584694645485522352", 0)
addappid(205105, 1, "a5edbaafa3576d51111b4438ae92e73c92252a0970b1c6ed8367fc7db8a1ce18") --Main Windows Language Depot German Dishonored
setManifestid(205105, "3894833290655216485", 0)
addappid(205106, 1, "f406f5908d05fc3baa1c5655ca150862c08a29163d2e956d45c22ca43a55ef35") --Main Windows Language Depot Spanish Dishonored
setManifestid(205106, "194686839392658586", 0)
addappid(205107, 1, "4c832577b21680c03a9dfc8e66a8e7448e5233b9f9037c123be0a7fb36e32dbe") --Main Windows Depot Dishonored
setManifestid(205107, "3090641581836335173", 5220784)
--Dlcname Dishonored: Dunwall City Trials DLC
addappid(208570, 1, "d5f8adf6db0731cd395883db60b943cf3c83d2d447084a3111822237c1f56fe4") --Dlcname Dishonored: Dunwall City Trials DLC
setManifestid(208570, "4109763437725695359", 0)
--Dlcname Dishonored: The Knife of Dunwall
addappid(208575, 1, "ccddbb489f2ba68ba8ab5239862de740f6bfe8871f1d6336bc9364cbf012dd4c") --Dlcname Dishonored: The Knife of Dunwall
setManifestid(208575, "5118738034433535542", 0)
--Dlcname Dishonored: The Brigmore Witches
addappid(212894, 1, "9db7ad1dd15bd13765ae84a6b4f3a6fb5d6947c4c334781e68f96d244989e52f") --Dlcname Dishonored: The Brigmore Witches
setManifestid(212894, "6290470269679908951", 0)
addappid(212890) --Dlcname Dishonored Shadow Rat Pack
addappid(212891) --Dlcname Dishonored Backstreet Butcher Pack
addappid(212892) --Dlcname Dishonored Arcane Assassin Pack
addappid(212893) --Dlcname Dishonored: Void Walkers Arsenal