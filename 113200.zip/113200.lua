-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 113200.lua
--Gamename The Binding of Isaac
addappid(113200, 1, "25d16c3477939d0cc439a4dfe9e674aeeba511e5cdbdcd28befad075b8d0d73d") --Mainappid The Binding of Isaac
addappid(113201, 1, "dc46feac7ce6fc9f0620f632205abb4ed111519738ebcca5cb8593b96fe79350") --Main Windows Depot The Binding of Isaac
setManifestid(113201, "7053554676601365183", 0)
addappid(113202, 1, "9e69039d873162e477325961ff4a656c072ecec3ceef660e15b1c385858a374e") --Main Macos Depot The Binding of Isaac
setManifestid(113202, "3180483545280594364", 0)
--Dlcname Binding of Isaac Soundtrack
addappid(113203, 1, "b5cba50948d0305ebde3371d94859ca28fb851407c66be924e02888de9d10802") --Dlcname Binding of Isaac Soundtrack
setManifestid(113203, "7017059398181616414", 0)
--Dlcname Binding of Isaac: Wrath of the Lamb
addappid(113204, 1, "05562ce646f2fc39742720cf096bf8fee36ab13993609dbe48f87451ec9f6bd6") --Dlcname Binding of Isaac: Wrath of the Lamb
setManifestid(113204, "6614082919839273692", 0)
--Dlcname The Binding Of Isaac - Wrath of the Lamb
addappid(113205, 1, "847e6dd2cb0127abffeb458938c293384e72d1031a0ead9a4ff03bbb104bdf81") --Dlcname The Binding Of Isaac - Wrath of the Lamb
setManifestid(113205, "190163795382615836", 0)
--Dlcname The Binding of Isaac: Wrath of the Lamb Eternal Edition
addappid(368010, 1, "ef8ea30154f995c4e4226df06f5cc39705ef0fc2d800f948613d1b3dd6b6437e") --Dlcname The Binding of Isaac: Wrath of the Lamb Eternal Edition
addappid(113206, 1, "2f6ec6d6771460d872d815dd7190331aa9eea92b510d52ab72e223bd8602efde") --Dlc Macos Depot The Binding of Isaac: Wrath of the Lamb Eternal Edition
setManifestid(113206, "8639075337300603337", 49332192)
setManifestid(368010, "6622130648560741481", 48723536)