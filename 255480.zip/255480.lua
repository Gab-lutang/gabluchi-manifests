-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 255480.lua
--Gamename NBA 2K14
addappid(255480) --Mainappid NBA 2K14
addappid(255481, 1, "280addab6a3a224d1b4c245b3778ac8658b447284c8d41ed73e4bc027d7e6327") --Main Windows Depot NBA 2K14
setManifestid(255481, "7773500769044867124", 0)
--Share Depots
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)