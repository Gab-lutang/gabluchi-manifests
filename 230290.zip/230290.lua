-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 230290.lua
--Gamename Universe Sandbox
addappid(230290, 1, "646f1ae2391838142b4ec9c82016313256b8c31e31b39bf343e1f82002443441") --Mainappid Universe Sandbox
addappid(230291, 1, "d4032e706d2ed817e94dbf0ee8e96854deacf119261215d15a4f11b481673e64") --Main Windows/Linux Depot Universe Sandbox
setManifestid(230291, "4735038136754865180", 1761881392)
addappid(230292, 1, "7a549608cadcf13742cccc734cbca6b6080db136ac34e96993fbf0cc8da7db8c") --Main Macos Depot Universe Sandbox
setManifestid(230292, "4142249734663858726", 1730087424)
--Share Depots
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228985, "3966345552745568756", 13244128)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228986, "8782296191957114623", 23045488)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)