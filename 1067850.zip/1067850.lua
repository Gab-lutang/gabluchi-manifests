-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1067850.lua
--Gamename Kindergarten 2
addappid(1067850) --Mainappid Kindergarten 2
addappid(1067851, 1, "e0607940b6fe9ca06f82a11e911ea1adaac05771e3601e898b420add1c69b84c") --Main Windows Depot Kindergarten 2
setManifestid(1067851, "9111284029029028489", 55823280)
addappid(1067852, 1, "c1a72252faf7b567591c555dc118c95d80b2038e27c452ff082a4fa833442df3") --Main Macos Depot Kindergarten 2
setManifestid(1067852, "8775913596936263416", 62721248)
addappid(1067853, 1, "2448db16e64fadcaa8c5c86011df00808c5b607101aeee3cbbb110bf895d0781") --Main Linux Depot Kindergarten 2
setManifestid(1067853, "1437063333715820272", 56700640)