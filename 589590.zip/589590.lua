-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 589590.lua
--Gamename Kindergarten
addappid(589590) --Mainappid Kindergarten
addappid(589591, 1, "f9fe28f6c18c25c8be516b85cc496859a657baa4343657a09071ad41f1822830") --Main Windows Language Depot English Kindergarten
setManifestid(589591, "4473152082461926354", 39980224)
addappid(589592, 1, "b9446b93c57c0b981214881c5d929fb1d2c6e67509156f2391073be286f8ef86") --Main Macos Language Depot English Kindergarten
setManifestid(589592, "6185142043972229225", 46597872)
addappid(589593, 1, "79ceeca88181cc1d988549589566a0b6655bf506c907549e9361207c29449abe") --Main Linux Language Depot English Kindergarten
setManifestid(589593, "3879841614094701495", 41038144)
addappid(589594, 1, "58a77fd535008605d6d16f51f3ade1c0942b82e30dd86bdfbe8e7a08becdc3b3") --Main Windows Language Depot Spanish Kindergarten
setManifestid(589594, "5181410782585379", 27998960)
addappid(589595, 1, "77d22de7cab9fdcb85f02c292e0cc1377e40921487b1e0f9aacc51b8948881c8") --Main Macos Language Depot Spanish Kindergarten
setManifestid(589595, "6767627757520307276", 30545184)
addappid(589596, 1, "2090ae1c803ddd9e02c827c6e6e83b4f164e949a95b3c85a158bc59df767978e") --Main Linux Language Depot Spanish Kindergarten
setManifestid(589596, "3694063376426979196", 31670496)