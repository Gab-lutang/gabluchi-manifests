-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 976730.lua
--Gamename Halo: The Master Chief Collection
addappid(976730, 1, "ee5f1e5eb0e59c3f87d057221ed6493922c26bff40909dfb132627ff7ebb6436") --Mainappid Halo: The Master Chief Collection
addappid(976731, 1, "e877debc3a91a6d843e9828dbb89dd67611541ea3794963e24bf0ee96ba550d9") --Main Windows Depot Halo: The Master Chief Collection
setManifestid(976731, "4956458579120161185", 10431492112)
--Dlcname Halo: Reach
addappid(1064220) --Dlcname Halo: Reach
addappid(1064225, 1, "90afd6a2b72722120fd9096bac881d25d598fb19bbe3787bf7ca715336ece14b") --Dlc Windows Depot Halo: Reach
setManifestid(1064225, "2839831772411294252", 6664093552)
--Dlcname Halo: Combat Evolved Anniversary
addappid(1064221) --Dlcname Halo: Combat Evolved Anniversary
addappid(976733, 1, "6be42af36216470c4dd76f02aa8dcbb7fb616bc1ea81121e94e11bc4980abf55") --Dlc Windows Depot Halo: Combat Evolved Anniversary
setManifestid(976733, "886692270880710564", 8485033200)
--Dlcname Halo 2: Anniversary
addappid(1064270) --Dlcname Halo 2: Anniversary
addappid(976735, 1, "c6639bef3cdcf9bf27644c31d10c4735c28a17bc7ca32a52ddd10f189dc70c75") --Dlc Windows Depot Halo 2: Anniversary
setManifestid(976735, "3171334642139802443", 22003386656)
--Dlcname Halo 3
addappid(1064271) --Dlcname Halo 3
addappid(976738, 1, "b01b615b4689becd286be89f3b324b9a6537cd21c352c4d922abf59d0e0ba241") --Dlc Windows Depot Halo 3
setManifestid(976738, "5942743121382725562", 7449085440)
--Dlcname Halo 3: ODST
addappid(1064272) --Dlcname Halo 3: ODST
addappid(1064222, 1, "fe97b6cd8f90c44e0944c52eb85a2b77dc24b87e7d0b472d4e3047e7e4ecc22e") --Dlc Windows Depot Halo 3: ODST
setManifestid(1064222, "4251229898993976945", 6973478688)
--Dlcname Halo 4
addappid(1064273) --Dlcname Halo 4
addappid(1064223, 1, "468a5cc3d2fe62537017351460d269ee33cd6f06b4cf8d62bd1ddc83dd758610") --Dlc Windows Depot Halo 4
setManifestid(1064223, "6380080023131513473", 21094649376)
--Dlcname AppID 1080080
addtoken(1080080, "16757144231569661271")
addappid(1080080) --Dlcname AppID 1080080
addappid(976734, 1, "c912351548ff554431c1dda0ce05515bdb2251fe6fdf30dbfb70fb6f85dbf2ad") --Dlc Windows Depot AppID 1080080
setManifestid(976734, "7232036684651310417", 4488971344)
--Dlcname MCC - H4: Multiplayer
addappid(1097220) --Dlcname MCC - H4: Multiplayer
addappid(1064224, 1, "e6880c811ede7146b056ae9a93ea9da2fd5f25e0eecbdec0c503ab407486e97a") --Dlc Windows Depot MCC - H4: Multiplayer
setManifestid(1064224, "6517281113684597986", 15951621424)
--Dlcname AppID 1097222
addtoken(1097222, "2791348385504549869")
addappid(1097222) --Dlcname AppID 1097222
addappid(976739, 1, "fe5f4c78a180f1896e8d82f03ee942d48a2df63ba5ee39438f3c89b675c55926") --Dlc Windows Depot AppID 1097222
setManifestid(976739, "3902112679418599911", 7434729536)
--Dlcname MCC - H2: Multiplayer
addappid(1097223) --Dlcname MCC - H2: Multiplayer
addappid(976736, 1, "17d2adb7c2c423be7b4326040b85c0a0261e3608bd0cd93f2a2f83aee9f73e78") --Dlc Windows Depot MCC - H2: Multiplayer
setManifestid(976736, "7615983289011416505", 14010963392)
addappid(976737, 1, "454193d47f594693dedcd4efc6dabf1330834e1e7f9bd2476893fb22bdba8bd1") --Dlc Windows Depot MCC - H2: Multiplayer
setManifestid(976737, "2116658161440873010", 6646530288)
--Dlcname AppID 1097224
addtoken(1097224, "11572389741647076")
addappid(1097224) --Dlcname AppID 1097224
addappid(1064226, 1, "29b66b00377f450613be6976878fd65f1ad1690a447955a9193209aefa8b79f1") --Dlc Windows Depot AppID 1097224
setManifestid(1064226, "1185971278520087384", 5627002928)
--Dlcname MCC - H1: Extended Language Pack
addappid(1108760) --Dlcname MCC - H1: Extended Language Pack
addappid(1064228, 1, "db8da685c10ff2529ce5c1463257efe2bfa7c696659c61a79cfa681dfdebc412") --Dlc Windows Depot MCC - H1: Extended Language Pack
setManifestid(1064228, "6740673267375754218", 818822032)
--Dlcname MCC - H2: Extended Language Pack
addappid(1108761) --Dlcname MCC - H2: Extended Language Pack
addappid(1064229, 1, "048f45b36d0322ff371ef021c2b129fd5978efcb30069bc5c5c837755735cbf2") --Dlc Windows Depot MCC - H2: Extended Language Pack
setManifestid(1064229, "4496935266254945644", 506286448)
--Dlcname AppID 1108762
addtoken(1108762, "16279060983445300922")
addappid(1108762) --Dlcname AppID 1108762
addappid(1064274, 1, "988e24b4710ed5e80835a2d5247657503c2763a0d68639c5d15fdee0272eb71d") --Dlc Windows Depot AppID 1108762
setManifestid(1064274, "1012731833906676734", 1635718192)
--Dlcname MCC - ODST: Extended Language Pack
addappid(1108763) --Dlcname MCC - ODST: Extended Language Pack
addappid(1064275, 1, "39eb442343708c7c58460969f157d25779630c6cf0997712e2a1840b8436651d") --Dlc Windows Depot MCC - ODST: Extended Language Pack
setManifestid(1064275, "7410615082723943400", 1404420576)
--Dlcname MCC - H4: Extended Language Pack
addappid(1109620) --Dlcname MCC - H4: Extended Language Pack
addappid(1064276, 1, "63fd98d1855f6f4df7af9606096267823059a5c0102e1c68b5c1897757781de5") --Dlc Windows Depot MCC - H4: Extended Language Pack
setManifestid(1064276, "8919231023149142163", 3094921520)
--Dlcname AppID 1109621
addtoken(1109621, "12870953071227487373")
addappid(1109621) --Dlcname AppID 1109621
addappid(1064227, 1, "b6a746262310138d6b402da8bda7e51ae43500dc08a97c44a832d6fb61c3d832") --Dlc Windows Depot AppID 1109621
setManifestid(1064227, "2902300282061187148", 1231502528)
--Share Depots
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228987, "4302102680580581867", 22936736)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") --Share Windows Depot Steamworks Common Redistributables
setManifestid(229005, "7992454656023763365", 62722592)