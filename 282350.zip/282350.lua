-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 282350.lua
--Gamename NBA 2K15
addappid(282350, 1, "2a6ccc525d67df944f3fbc05f544dc37b789596233d94ec43750b4eff24de444") --Mainappid NBA 2K15
addappid(282351, 1, "51165e44f2e4406d9d66f29d832300025d6c817d9232d70355344170ef133ceb") --Main Windows Depot NBA 2K15
setManifestid(282351, "3364312417142647817", 46700497632)
--Share Depots
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(323360) --Dlcname KD MVP Bonus Pack
addappid(386730) --Dlcname NBA 2K16 Pre-order Virtual Currency for 2K15
addappid(400480) --Dlcname NBA 2K16 Pre-Order VC for JP