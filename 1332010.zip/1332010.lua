-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1332010.lua
--Gamename Stray
addappid(1332010, 1, "768901ded35b97e8a2bf33726d11318f4251ed6830daf4d0fd00e5e1c787b52b") --Mainappid Stray
addappid(1332011, 1, "e61bdb7aeaccc075f69345348178ac158f107c1433c9a28743797407dc335e4c") --Main Windows Depot Stray
setManifestid(1332011, "1060673695878105362", 6441802096)
addappid(1332012, 1, "b0288825cade4cf4aceb6bf5a2e523e0c94028b45fe8095fea1f7e04e26f5728") --Main Macos Depot Stray
setManifestid(1332012, "1039060348056700964", 7710868320)
--Share Depots
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228988, "6645201662696499616", 22411856)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)