-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 952060.lua
--Gamename Resident Evil 3
addappid(952060, 1, "33f1f38944fcd86f77d1c0efcf06ea0f892a2997c6912166a5445f486137670c") --Mainappid Resident Evil 3
addappid(952061, 1, "59cd6a454139aeaf999cc3dde8aeb2e0c4dd0e1264c9d87bf0a7e702d892e68a") --Main Windows Depot Resident Evil 3
setManifestid(952061, "3564315731812381316", 21809067424)
addappid(952062, 1, "fdfbc9447d8302b8a7b325ec2bccaa81e77cef9d8289ead20348a702cce53e40") --Main Windows Depot Resident Evil 3
setManifestid(952062, "3791699160523467767", 21727940128)
addappid(1348140, 1, "e8a976042344885d95857a7d7072257b20f13d58bf8e48eaf31ba5f3bf3a7d29") --Main Windows Depot Resident Evil 3
--Dlcname RESIDENT EVIL 3 - Classic Costume Pack
addappid(1158730) --Dlcname RESIDENT EVIL 3 - Classic Costume Pack
addappid(952063, 1, "e5e87afc561b9663966c6f3fb6a9de1dac7466dfb32db183fbcfbeb5f011257b") --Dlc Windows Depot RESIDENT EVIL 3 - Classic Costume Pack
setManifestid(952063, "7504296696893507629", 565900192)
--Dlcname Resident Evil 3 - All In-game Rewards Unlock
addappid(952064, 1, "438a8c22458963cec5059bec6e195c24b9988cf2c2d2a33298db12146597812c") --Dlc Windows Depot Resident Evil 3 - All In-game Rewards Unlock
setManifestid(952064, "4916965303803227400", 10800)
--Share Depots
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228988, "6645201662696499616", 22411856)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)