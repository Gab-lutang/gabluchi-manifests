-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 370240.lua
--Gamename NBA 2K16
addappid(370240) --Mainappid NBA 2K16
addappid(370241, 1, "2834e0599f82797bd1af42488a12abeb892bd2d3e9a8ce684fd601e6e56c1cab") --Main Windows Depot NBA 2K16
setManifestid(370241, "476087243588707670", 47350537600)
--Share Depots
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228984, "2547553897526095397", 13436144)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(386720) --Dlcname NBA 2K16: Michael Jordan Edition
addappid(386721) --Dlcname NBA 2K16: Pre-Order Content
addappid(486710) --Dlcname NBA 2K17: Pre-Order offer for NBA 2K16