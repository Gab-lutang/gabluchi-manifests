-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 732430.lua
--Gamename Superflight
addappid(732430) --Mainappid Superflight
addappid(732431, 1, "52ff73e06c3cc683bc6f5e520890ceb348d8e10384fd65473d6b04e1c2d9b9ec") --Main Windows Depot Superflight
setManifestid(732431, "5306840167420376550", 33948000)
addappid(732432, 1, "2f2b2163c42839f1358143bc31639104b2b005ed242dba2bc84bfecfb8ae4a90") --Main Windows Depot Superflight
setManifestid(732432, "611761181964179892", 32317056)