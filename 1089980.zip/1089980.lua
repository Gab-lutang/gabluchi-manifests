-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1089980.lua
--Gamename The Henry Stickmin Collection
addappid(1089980) --Mainappid The Henry Stickmin Collection
addappid(1089981, 1, "da878117f6915a9c9b86b2c97d4798d72778c8b055ae3c4ea04a000d8902332f") --Main Windows Depot The Henry Stickmin Collection
setManifestid(1089981, "4187662908174128136", 444117056)
addappid(1089982, 1, "c4ec08e13cfd2970fcd8ec5ff1933e837c9b8af15ce635efd39ee5636caa0c15") --Main Macos Depot The Henry Stickmin Collection
setManifestid(1089982, "105448427528528555", 441325536)