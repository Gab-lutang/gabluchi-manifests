-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 612880.lua
--Gamename Wolfenstein II: The New Colossus
addappid(612880, 1, "947eac8967656e9e3cf4b4a55aa1b0ab11dda6eff12b9f988a74fd1846e2d0a0") --Mainappid Wolfenstein II: The New Colossus
addappid(612882, 1, "d9aa24cc209df8e416ea797c131840676f26b57b5dbe2d0d99866474d304755d") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(612882, "332162649214284220", 36976896)
addappid(612883, 1, "c9b7a3baed5d35a9c24c81b571ce72da8e38e75ff57f1b7809046c0b482806d8") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(612883, "5036286170467120241", 10844713744)
addappid(612884, 1, "b6d8f534d5ec8bf04db31660757c5636454e29ade7141183cdf77e5edfb49aff") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(612884, "2122901492143408844", 7119525152)
addappid(612885, 1, "f0002d21bbb12a1cbcaf10fceede520be7d8b87e071c0f9f306ddd05caea957d") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(612885, "5038932946082422041", 1857626368)
addappid(612886, 1, "3d21a2226482d6e8326922884a089f2f61fc8aabaa8da7dcf49507b5269142a4") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(612886, "6858725330795673637", 12528523024)
addappid(612887, 1, "ca7800eddd8ba2e276b284cfb9420b1033e9e0c30baf88e373e6b9aa6603b6e3") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(612887, "8273162783244227988", 2307269328)
addappid(612888, 1, "be69fe4e99abe579beaca2b788c40e005b227efecaedb9757c45bdba209c5100") --Main Windows Language Depot Schinese Wolfenstein II: The New Colossus
setManifestid(612888, "4757386849333630100", 3140218464)
addappid(612889, 1, "9539f35bcc2bab1a9b6517a02cb2f44d295c651ffee2366d9899c12ee837b561") --Main Windows Language Depot Japanese Wolfenstein II: The New Colossus
setManifestid(612889, "7563900797837990703", 763254400)
addappid(624623, 1, "a5b6a8cdb2664e3cbf66f98e10db2c679394849d876df685b71d5011af41a550") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624623, "618551768872795601", 7353393520)
addappid(624624, 1, "9591bbda4d937a04aa952ac5e123f4a8feaa909dad9a17b68b659734c72bcb87") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624624, "8613853100061840797", 2306774832)
addappid(624625, 1, "dad0ea7aad27ea8abbd11a493d912b4ee7bc5c5354626ed540a86e630b4e93e6") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624625, "5214085521133308917", 12512714336)
addappid(624626, 1, "d75ad5fdc6e1b5a0736979e584703e04ddc4753fef7ccb27f986baac549fecc9") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624626, "6767799911521017463", 743209104)
addappid(624627, 1, "5eb4652adf06b6efe89cfd398ec58c662171ce7cee105331ecb39fe014a070cd") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624627, "3547469873055231551", 365113120)
addappid(624628, 1, "c826f4a417336153e99ce1506b7d4da5e70ca05ab81848220447bcd084b8d9d2") --Main Windows Language Depot French Wolfenstein II: The New Colossus
setManifestid(624628, "5783598834907555405", 710755712)
addappid(624629, 1, "ba7dd3d58ca23c51e9f179f1b18965fd1c3ec600d298d26afe88b5ecec434625") --Main Windows Language Depot Italian Wolfenstein II: The New Colossus
setManifestid(624629, "8742320481398942762", 730813280)
addappid(624741, 1, "733d51cea2f0e1807db6f58ac79ea5264c0db12fea18d22aceaa9db7803a1c4f") --Main Windows Language Depot Russian Wolfenstein II: The New Colossus
setManifestid(624741, "3086930858230260400", 1033252656)
addappid(624743, 1, "d63c0df8e700262db523d7a8d42abd2fa4c5367e07129af057b0d069a2ad976e") --Main Windows Language Depot Brazilian Wolfenstein II: The New Colossus
setManifestid(624743, "5675117221408475835", 698201264)
addappid(624744, 1, "1beac930c286cb764dfb6fd379fbf50ae325132b064e2b0716a581b3478cacf5") --Main Windows Language Depot Spanish Wolfenstein II: The New Colossus
setManifestid(624744, "7588974950788225158", 718686592)
addappid(624748, 1, "83a558c1199e3a2ea2083bc55fd5ed67d298bbc57f0e2dcd042316d252241f9c") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624748, "3592233195597680769", 10022383440)
addappid(624749, 1, "ad6398fc978e5a0b2ad763d2c398b7a1468fa7c9c4cd8980de79d0b5deca2af4") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(624749, "166817135839534724", 975313648)
addappid(650411, 1, "ca94d0179b21d0ee64b662f619849ee6f5a1d03c93745a23535679adea3569a3") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(650411, "317468368842259630", 10044183152)
addappid(650412, 1, "de127e37b1dab8f431e9d0f20ce4bd82c4aa001b57c9907636ed5aacb0ebc8d9") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(650412, "9022113729599668303", 927953008)
addappid(650413, 1, "58cca4e469e31f759e00b5d1ea252a71e4c538d3051aa3579ec3d10806b86703") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(650413, "4826278029060622680", 551890192)
addappid(650414, 1, "0bcf1f48c344ed5088f436998ae02f7c33e7e666b0cc04ff43ef2c738bb55f0e") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(650414, "1746396293235515966", 669648448)
addappid(650415, 1, "66c8ba97a64559e272aa9c60e0f90bf51bed0bde2ba8647b1c4d9c4b6f46dd66") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(650415, "1945011048598975996", 669636560)
addappid(650416, 1, "99de8d9f6977fd3a54b88b91fd35d2f4394c4ec4659d36638d3375b007d4ad41") --Main Windows Depot Wolfenstein II: The New Colossus
setManifestid(650416, "1613380009697405280", 35618544)
--Dlcname Wolfenstein II: The Freedom Chronicles - Episode 1
addappid(624620) --Dlcname Wolfenstein II: The Freedom Chronicles - Episode 1
addappid(762750, 1, "2ed466db2835036b650efcff72a34931a88fca7ff32c2990317e9a2e435a5936") --Dlc Windows Depot Wolfenstein II: The Freedom Chronicles - Episode 1
setManifestid(762750, "1153163775510174875", 3399843968)
--Dlcname Wolfenstein II: The Freedom Chronicles - Episode 2
addappid(624621) --Dlcname Wolfenstein II: The Freedom Chronicles - Episode 2
addappid(762740, 1, "518461383a927fa6f8b01c3ce717561a8061ec27057f00af03be400e4c4ac77e") --Dlc Windows Depot Wolfenstein II: The Freedom Chronicles - Episode 2
setManifestid(762740, "1386194745156710921", 3364235648)
--Dlcname Wolfenstein II: The Freedom Chronicles - Episode 3
addappid(624622) --Dlcname Wolfenstein II: The Freedom Chronicles - Episode 3
addappid(762730, 1, "d9969fc225d52c22003bab9092a13b5b2b40e8b35aadd653952e68da0bc637b2") --Dlc Windows Depot Wolfenstein II: The Freedom Chronicles - Episode 3
setManifestid(762730, "447099527328778696", 3358717936)
--Share Depots
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228986, "8782296191957114623", 23045488)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)
addappid(650410) --Dlcname Wolfenstein II: The Freedom Chronicles - Season Pass
addappid(719980) --Dlcname AppID 719980
addtoken(719980, "2693347029106600910")
addappid(624740) --Dlcname AppID 624740
addtoken(624740, "3911098109811334779")