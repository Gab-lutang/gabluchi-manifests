-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 223470.lua
--Gamename POSTAL 2
addappid(223470, 1, "ed67a3d0c291c55c88b2ea381b0698292bea6e88134e4bdd1f6f97a5423b5738") --Mainappid POSTAL 2
addappid(223471, 1, "f09d62d0b261d2cc2f87dc9a3696ea149b382d5358550cf62b80e6c7966b62a1") --Main Linux Depot POSTAL 2
setManifestid(223471, "928416563707754395", 0)
addappid(223472, 1, "dc7ba18430bcecfd6ac052e8ab1f688162df610c4caa7bc7a4efe0fb586f9d47") --Main Macos Depot POSTAL 2
setManifestid(223472, "8599926391484992213", 0)
addappid(223473, 1, "1eb8e59a1ed178096ae7435195a2606ee86f9dc5ab872debfc3eaee112c47ffe") --Main Linux Depot POSTAL 2
setManifestid(223473, "6691581963788888388", 0)
addappid(223474, 1, "b96211d79ac6db952b6268b04f59ceb40def4314bfc3bc7433f9e16e2d6bb534") --Main Windows Depot POSTAL 2
setManifestid(223474, "8245567315972874028", 6899360)
addappid(223475, 1, "3bac0977f1a43295c2ec28e88040979b593e845474bb223c919ce54900021bed") --Main Macos Depot POSTAL 2
setManifestid(223475, "604463339686132072", 0)
addappid(223476, 1, "828da9e5e0867962e1ff391958b928e61d31738b233f17ef98252efffdd82cdf") --Main Macos Depot POSTAL 2
setManifestid(223476, "624469682414553862", 9230800)
addappid(223477, 1, "54bdac3d47c172eef05b30e5684a8ebc4a4e5c9b4b11550cacd995643904ce69") --Main Linux Depot POSTAL 2
setManifestid(223477, "7835361068977694598", 23915664)
addappid(223478, 1, "0953aa125efe46f01feab2207119ee2d7010bb1e881348794816bd296f157e3c") --Main Windows Depot POSTAL 2
setManifestid(223478, "5752353636539970910", 1948291520)
addappid(223479, 1, "878f826d7149590383b8e23a37c8be648401e720f0d55932231575d4b36b4162") --Main Windows Language Depot Russian POSTAL 2
setManifestid(223479, "4747940830676175413", 380616704)
addappid(223480, 1, "c51639e25de9912d275b257676a5233e5c68a1546b3a181de33d481d9689488d") --Main Windows Depot POSTAL 2
setManifestid(223480, "959739473586123837", 0)
addappid(223481, 1, "21d9c042cd42442e515f3e68b951bffc6a485ad97feba4b69ff2e2f9d482861b") --Main Windows Language Depot Schinese POSTAL 2
setManifestid(223481, "548099121658717884", 546371792)
addappid(223482, 1, "7315266efd855f9a47c5619ee6b0dbf34a2bc4e609b45dce3c4545fdf76f0deb") --Main Windows Language Depot English POSTAL 2
setManifestid(223482, "282827848994046687", 0)
addappid(223483, 1, "9b66817b6809e6441b23d3617dcd8e69617f3cc3b68ce88459df780cb0913bee") --Main Windows Language Depot Spanish POSTAL 2
setManifestid(223483, "6547057908306726508", 114325040)
addappid(223484, 1, "e374ee7eb877dc43b57c2be878e646a1ec4fd9059622c5ad30d8f8e55617e82c") --Main Windows Language Depot Turkish POSTAL 2
setManifestid(223484, "8556639717861697639", 114449600)
addappid(223485, 1, "7f39e72eeceefd3749f65c7709b09cdb7c4f73e4c1b34d4092fc13a2dc510030") --Main Windows Language Depot Portuguese POSTAL 2
setManifestid(223485, "4564505287090823057", 114462576)
--Dlcname POSTAL 2: Paradise Lost
addappid(360960, 1, "47665ba7fcf8a7b0453d142d40767bfdbac662927cbc18f639e554f619c80362") --Dlcname POSTAL 2: Paradise Lost
setManifestid(360960, "902017090237861031", 1290236080)
addappid(360961, 1, "d8644dfd06676cf6917af6516b8c6e330761d1881d0c1bb76d44a744e109a184") --Dlc Windows Depot POSTAL 2: Paradise Lost
setManifestid(360961, "8843324829041529959", 2610304)
addappid(360962, 1, "ec673cc49cdbe6ecf3fed4f98b1d3b5e8ef9f27ad6d243efc128b68886da784f") --Dlc Linux Depot POSTAL 2: Paradise Lost
setManifestid(360962, "3576856913910864507", 24677808)
addappid(360963, 1, "f328c57f087814da711078b76d7919aacd49eb64632d18aee134c7de047c986b") --Dlc Macos Depot POSTAL 2: Paradise Lost
setManifestid(360963, "1876099560378761628", 7365456)
addappid(360964, 1, "0b34d15fdfe4572313d157e67ef58db076ccf3afe454feef19f9e595b7804aa9") --Dlc Windows Language Depot Russian POSTAL 2: Paradise Lost
setManifestid(360964, "204026484203066734", 144)
addappid(360965, 1, "531bdd4d12040f2239f94a3ab0b41ef253fb6ab585273bbf4a54079c9138fafc") --Dlc Windows Language Depot Schinese POSTAL 2: Paradise Lost
setManifestid(360965, "2974156804144002374", 58842000)
addappid(360966, 1, "63aa8d43fc064af22b90b589362c7905ef9bf2f136c64d2c982563238884962e") --Dlc Windows Language Depot English POSTAL 2: Paradise Lost
setManifestid(360966, "703149013489642967", 0)
--Share Depots
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228981, "7613356809904826842", 5804736)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228983, "8124929965194586177", 19214528)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228985, "3966345552745568756", 13244128)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Share Windows Depot Steamworks Common Redistributables
setManifestid(228990, "1829726630299308803", 100658080)