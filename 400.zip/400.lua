-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 400.lua
--Gamename Portal
addappid(400, 1, "3c3c47f502a7d112bfb98a81c469df7add3b758b225b28310b1b0a8c9b255454") --Mainappid Portal
addappid(401, 1, "3ed55d26ffdf7f6c5e228ec60127ddc1712f341cfb082cadb9cebbd0f64d0d7d") --Main Windows Depot Portal
setManifestid(401, "3169084482272098670", 2522547296)
addappid(402, 1, "1d9699c90f13a7549a97e5935b9eb152502aa664ce6944a56573c5f9a5c6d2f1") --Main Windows Depot Portal
setManifestid(402, "7655374749121348667", 64607136)
addappid(403, 1, "1349997dfe5e13cb91d43d7076e499e92da34710020fb4d3d58c385e5092c837") --Main Macos Depot Portal
setManifestid(403, "8974907495363134881", 33780816)
addappid(404, 1, "552f270a24f114f8eb9ccaad3502d0f30f8950c67fcb62b2752f1ae5bd9eb2e1") --Main Linux Depot Portal
setManifestid(404, "1961797017312074949", 51396928)
addappid(405, 1, "a727634c8c0d6f750077fb397fb5d4848b1a31f7cefcb0e3295bbbed05af1b6a") --Main Windows Language Depot Russian Portal
setManifestid(405, "453200351187428393", 76108208)
addappid(406, 1, "3bfe4846e06d664c531bb61e2f35737653d9099497522b38fd15a355acd5339c") --Main Windows Language Depot Spanish Portal
setManifestid(406, "8904830885129684315", 103692368)
addappid(407, 1, "e9eafe69caa4384a1b69193f12c7f4dbbe65a71a76e178b988260524b2a4c3ba") --Main Windows Language Depot French Portal
setManifestid(407, "8242589767738537927", 112107920)
addappid(408, 1, "a6254ee5cef5797432b6ae404018d028c955596cbfa5ff3fece97a9cd6534d1b") --Main Windows Language Depot German Portal
setManifestid(408, "8794244784218856360", 114173696)
addappid(409, 1, "28cf5b133c63b6f5f1fab9d376b3ce35c7dd327505459288ae8d772a262c48f4") --Main Windows Depot Portal
setManifestid(409, "5466869569815608374", 2355896560)
addappid(410, 1, "6bb84a4ff29b21f5f3e52a121c1293ad75c92ba8ad0b050fa691a9c15164a5e9") --Main Windows Depot Portal
setManifestid(410, "106212190778449766", 3104)